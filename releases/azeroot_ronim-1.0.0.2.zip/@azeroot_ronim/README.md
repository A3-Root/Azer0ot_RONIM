# Azer0ot_RONIM

![version](https://img.shields.io/badge/version-1.0.0.2-blue)
[![build](https://github.com/A3-Root/Azer0ot_RONIM/actions/workflows/auto-release.yml/badge.svg?branch=master)](https://github.com/A3-Root/Azer0ot_RONIM/actions/workflows/auto-release.yml)

**RONIM - Realistic Optic Nightvision Integration Mechanism** makes NVGs behave like real tubes, most of all when you aim through a magnified optic with them.

Authors: **Root, Azer0**. Requires **CBA**. **ACE** and **ZEN** are optional; RONIM uses them when they are loaded.

## Features

| # | Feature | When |
|---|---|---|
| 1 | **PiP night vision and tube sway.** In first person RONIM renders the night vision itself, in a local picture-in-picture view inside its own tubes (monocular, binocular or quad), and keeps the game's NVG mode off, so no vanilla or ACE tube overlay is drawn. A monocular leaves the other eye with the real view. The tubes lag behind head turns, bob as you walk and drift more as you tire. Third person, or PiP turned off in video options, falls back to the game's NVG mode. | NVGs on |
| 2 | **Mount failure.** A shot can break the mount, and the goggles fall to the ground. Stronger rounds break it more often. | magnified optic |
| 3 | **Recoil bruise.** Recoil can push the NVG into your face and cause a head contusion (ACE medical) or minor head damage (vanilla). There is a cooldown between bruises. | magnified optic |
| 4 | **Independent ADS sway and misalignment.** The tubes sway out of step with the weapon, and recoil knocks them. A shot can shift the mount off centre. The mount is fixed by toggling the NVGs, by recovering on its own over about 5.5 s, or with the ACE self-action *Re-seat NVG mount* (about 5.5 s). | magnified optic |
| 5 | **Muzzle flash bloom.** An unsuppressed shot washes the image out white for a moment. Unsuppressed shots from nearby units can do the same (optional). Flash hiders do not count as suppressors. | magnified optic (configurable) |
| 6 | **Reticle.** The NV picture covers the scope, so the optic's reticle (dot, cross, chevron or mil-dot, set per optic) is drawn on top at the aim point. Sway and misalignment move the picture against it. In game NVG mode a monocular gets a copy of the reticle on the eye without the tube. | magnified optic |

"Magnified optic" means aiming with NVGs on through an optic at or above the magnification threshold (default 1.5x). Iron sights and holo sights only get feature 1. Optics with their own NVG or thermal mode, whether auto-detected or listed, get none of features 2-6.

## Configuration

- **CBA settings:** 76 settings under *Addon Options > RONIM - Optic Nightvision*. See [docs/SETTINGS.md](docs/SETTINGS.md).
- **Zeus (ZEN):** settings, feature toggles, exempt unit, break mount, re-seat mount, integrated optics. See [docs/MODULES.md](docs/MODULES.md).
- **3DEN:** the *RONIM Settings* module, the *RONIM Exempt Units* module, and a unit attribute *RONIM: exempt*.
- **API:** `azeroot_ronim_fnc_*` functions and CBA events. See [docs/API.md](docs/API.md).

## ACE notes

- In PiP mode the game's NVG mode stays off, so ACE Nightvision's grain, blur and mask only apply in third person or with PiP off.
- In game NVG mode, ACE Nightvision draws its own fixed tube mask. RONIM hides it and draws its own instead. You can change this with the *ACE NVG mask handling* setting.
- ACE's own `ace_nightvision_shutterEffects` blink stacks with RONIM's bloom. Turn one of them off if you only want one.
- `ace_nightvision_disableNVGsWithSights` turns NVGs off while aiming, which leaves features 2-6 nothing to act on.

## Building

```
python tools/gen_settings.py    # after editing the settings table
python tools/gen_textures.py    # after editing masks / reticles (numpy, Pillow)
hemtt ln sort
hemtt check -p -Lc14 -e
hemtt release
```
