name = "RONIM - Realistic Optic Nightvision Integration Mechanism";
author = "Root, Azer0";
overview = "Realistic night vision through magnified optics.";

timestamp = 639271597020000000;
